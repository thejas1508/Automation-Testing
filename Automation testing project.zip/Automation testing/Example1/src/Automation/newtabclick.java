package Automation;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class newtabclick {
	public static void main(String[] args) throws InterruptedException {
	    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	    ChromeDriver d = new ChromeDriver();
	    d.get("https://demoqa.com/browser-windows/");
	    WebElement button = d.findElement(By.id("tabButton"));
	    button.click();
	    String windowHandles = d.getWindowHandle();
	    System.out.println(windowHandles);
        Thread.sleep(3000);
        Set<String> newWindows = d.getWindowHandles();
        for (String allTabs : newWindows) {
        	d.switchTo().window(allTabs);
			
		}
	}
}