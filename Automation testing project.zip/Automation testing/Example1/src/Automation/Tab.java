package Automation;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Tab {
	public static void main(String[] args) throws InterruptedException {
	    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	    ChromeDriver d = new ChromeDriver();
	    d.get("https://demoqa.com/browser-windows/");
	    WebElement button = d.findElement(By.id("tabButton"));
	    button.click();
	    String windowHandles = d.getWindowHandle();
	    System.out.println(windowHandles);
        Thread.sleep(3000);
        Set<String> newWindows = d.getWindowHandles();
        for (String allTabs : newWindows) {
        	d.switchTo().window(allTabs);
			
		}
        d.close();
        d.switchTo().window(windowHandles);
        WebElement button1 = d.findElement(By.id("windowButton"));
	    button.click();
	  
        Set<String> newWindows1 = d.getWindowHandles();
        for (String all1Tabs1 : newWindows) {
        	d.switchTo().window(all1Tabs1);
        	Thread.sleep(3000);
        	
        }
        d.close();
       
   
	   
	    
	   
	    
	}
}