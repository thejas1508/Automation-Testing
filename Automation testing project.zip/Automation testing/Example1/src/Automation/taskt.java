package Automation;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class taskt {
	public static void main(String[] args) throws IOException, InterruptedException {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.get("https://fs2.formsite.com/meherpavan/form2/index.html?");
    d.manage().window().maximize();
    WebElement fname = d.findElement(By.id("RESULT_TextField-1"));
    fname.sendKeys("TIGER");
    WebElement lname = d.findElement(By.id("RESULT_TextField-2"));
    lname.sendKeys("THEJAS");
    WebElement Gender = d.findElement(By.xpath("//*[@id=\"q26\"]/table/tbody/tr[1]/td/label"));
    Gender.click();
    WebElement Phoneno = d.findElement(By.id("RESULT_TextField-3"));
	Phoneno.sendKeys("9392832148");
	WebElement Country = d.findElement(By.id("RESULT_TextField-4"));
	Country.sendKeys("NEWZELAND");
	WebElement City = d.findElement(By.id("RESULT_TextField-5"));
	City.sendKeys("CHENNAI");
	WebElement Email = d.findElement(By.id("RESULT_TextField-6"));

	Email.sendKeys("thejaskumar.b35@gmail.com");

	//JavascriptExecutor java = (JavascriptExecutor )d;

	//java.executeScript("window.scrollBy(0,1000)");

	WebElement Sunday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[1]/td/label"));	

	Sunday.click();


	WebElement Monday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[2]/td/label"));	

	Monday.click();

	WebElement Tuesday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[3]/td/label"));	

	Tuesday.click();


	WebElement Wednesday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[4]/td/label"));	
	Wednesday.click();
	WebElement Thursday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[5]/td/label"));	
	Thursday.click();
	WebElement Friday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[6]/td/label"));	
	Friday.click();
	WebElement Saturday = d.findElement(By.xpath("//*[@id=\"q15\"]/table/tbody/tr[7]/td/label"));	
	Saturday.click();
	WebElement Time = d.findElement(By.xpath("//*[@id=\"RESULT_RadioButton-9\"]")); 
	Select Time1  = new Select(Time);
	Time1.selectByVisibleText("Afternoon");
	System.out.println("Afternoon selected");
	WebElement File = d.findElement(By.id("RESULT_FileUpload-10"));
	String filePath = "C:\\selenium\\chrome";
	File.sendKeys(filePath);
	Thread.sleep(3000);

	WebElement Submit = d.findElement(By.xpath("//*[@id=\"FSsubmit\"]"));	
	Submit.click();
	TakesScreenshot ss = (TakesScreenshot)d;

	File source = ss.getScreenshotAs(OutputType.FILE);

	File destination = new File("C:\\Users\\ADMIN\\Desktop\\Screenshot (178).PNG");

	org.openqa.selenium.io.FileHandler.copy(source, destination);


	}
    
    
	
}