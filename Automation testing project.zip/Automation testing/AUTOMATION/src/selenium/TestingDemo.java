package selenium;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class TestingDemo {
	public static void main(String[] args) throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
    d.get("https://demo.automationtesting.in/Alerts.html");
    WebElement Alert = d.findElement(By.xpath("//*[@id=\"OKTab\"]/button"));
    Alert.click();
    Thread.sleep(3000);
    Alert a1 = d.switchTo().alert();
    a1.accept();
    
    WebElement confirm = d.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[2]/a"));
	confirm.click();
	WebElement confirmbtn = d.findElement(By.xpath("//*[@id=\"CancelTab\"]/button"));
	confirmbtn.click();

	Thread.sleep(1500);

//	Alert ok = obj.switchTo().alert();

//	ok.accept();

	Alert cancel = d.switchTo().alert();

	cancel.dismiss();
	
	WebElement prompt = d.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[3]/a"));
	prompt.click();
	WebElement promptbtn = d.findElement(By.xpath("//*[@id=\"Textbox\"]/button"));
	promptbtn.click();
	Thread.sleep(1500);

	Alert text = d.switchTo().alert();

	text.sendKeys("Developer");

	text.accept();

//	text.dismiss();
	}
}
