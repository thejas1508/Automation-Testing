package selenium;
import org.openqa.selenium.chrome.ChromeDriver;
public class Class1 {
	public static void main(String[] args) {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
    d.get("https://www.google.co.in/");
    d.navigate().to("https://www.youtube.com/");
    String currenturl = d.getCurrentUrl();
    System.out.println("Current page URL is:"+currenturl);
    String pagetitle = d.getTitle();
    System.out.println("Current page Title is:"+pagetitle);
    d.navigate().back();
    d.navigate().forward();
	}

}
