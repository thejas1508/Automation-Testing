package selenium;
import org.openqa.selenium.chrome.ChromeDriver;
public class class3 {
	public static void main(String[] args) {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
    d.get("https://www.instagram.com/");
    d.navigate().to("https://www.supercell.com/");
    d.navigate().back();
    d.navigate().forward();
    d.close();
	}

}