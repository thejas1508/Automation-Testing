package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class class5 {
	public static void main(String[] args) throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
    d.get("https://demoqa.com/automation-practice-form");
    Thread.sleep(3000);
    WebElement fname = d.findElement(By.id("firstName"));
    fname.sendKeys("tiger");
    WebElement lname = d.findElement(By.id("lastName"));
    lname.sendKeys("THEJAS");
    WebElement Email = d.findElement(By.id("userEmail"));
    Email.sendKeys("tiger@gmail.com");
    WebElement Gender = d.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label"));
    Gender.click();
    WebElement MobNum = d.findElement(By.id("userNumber"));
    MobNum.sendKeys("7689243819");
    WebElement Sports = d.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[1]/label"));
    Sports.click();
    WebElement Reading = d.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[2]/label"));
    Reading.click();
    WebElement Music = d.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[3]/label"));
    Music.click(); 
    WebElement image = d.findElement(By.id("uploadPicture"));
    image.sendKeys("C:\\Users\\ADMIN\\Desktop");
    WebElement Address = d.findElement(By.id("currentAddress"));
    Address.sendKeys("17/1,tvs nagar,coimbatore");
    WebElement DateofBirth = d.findElement(By.id("dateOfBirthInput"));

	DateofBirth.click();



    WebElement desiredmonth = d.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select")); 

    Select month = new Select(desiredmonth);

    month.selectByVisibleText("August");

    System.out.println("March selected");

    

    WebElement desiredyear = d.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select")); 

    Select year = new Select(desiredyear);

    year.selectByVisibleText("2002");

    System.out.println("2004 selected");

    

	WebElement desiredDate = d.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[2]/div[3]/div[5]"));  

    desiredDate.click();
    

    }

}
