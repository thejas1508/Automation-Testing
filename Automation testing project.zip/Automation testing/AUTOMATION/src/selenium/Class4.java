package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Class4 {
	public static void main(String[] args) throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
    d.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    Thread.sleep(3000);
    WebElement username = d.findElement(By.name("username"));
    username.sendKeys("Admin");
    WebElement password = d.findElement(By.name("password"));
    password.sendKeys("admin123");
    WebElement Login = d.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button"));
    Login.click();
	}

}
