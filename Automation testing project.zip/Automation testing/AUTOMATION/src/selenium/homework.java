package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class homework {
	public static void main(String[] args) throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    ChromeDriver d = new ChromeDriver();
    d.manage().window().maximize();
  //  WebElement state = d.findElement(By.id("English"));
    //Select s2 = new Select(state);
   // s2.selectByIndex(2);
   // System.out.println("dropdown 2 selected");
    d.get("https://learner.demo.edunext.co/login?next=/api-docs/");
    Thread.sleep(3000);
    WebElement Email = d.findElement(By.id("login-email"));
    Email.sendKeys("tiger@gmail.com");
    WebElement Email = d.findElement(By.id("login-email"));
    Email.sendKeys("tiger@gmail.com");
    WebElement password = d.findElement(By.id("login-password"));
    password.sendKeys("tiger@15");
    WebElement Login = d.findElement(By.xpath("//*[@id=\"login\"]/button"));
    Login.click();
	}
}