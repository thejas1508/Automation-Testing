package selenium;


import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Class2 {
	public static void main(String[] args) {
	    System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	    ChromeDriver d = new ChromeDriver();
	    d.get("https://www.google.co.in/");
	    WebElement searchbox = d.findElement(By.id("APjFqb"));
	    Boolean enablecheck = searchbox.isEnabled();
	    System.out.println("Is textbox is enabled?"+enablecheck);
	    Boolean displaycheck = searchbox.isDisplayed();
	    System.out.println("Is textbox is enabled?"+displaycheck);
	    Dimension size =  searchbox.getSize();
	    System.out.println("Box size is?"+size);
	    d.navigate().to("https://demoqa.com/automation-practice-form");
	    
	    WebElement checkboxbutton = d.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label"));
	    boolean selectcheck = checkboxbutton.isSelected();
	    System.out.println("Is male Radiobutton Selected?"+selectcheck);
	    d.quit();
	    
	}

}
